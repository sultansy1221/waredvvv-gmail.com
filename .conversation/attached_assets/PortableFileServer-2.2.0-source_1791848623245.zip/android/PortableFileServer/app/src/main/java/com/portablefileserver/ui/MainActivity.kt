package com.portablefileserver.ui

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.portablefileserver.data.PrefsManager
import com.portablefileserver.qr.QrGenerator
import com.portablefileserver.server.ServerRuntime
import com.portablefileserver.server.ServerService
import java.io.File
import java.security.SecureRandom

class MainActivity : Activity() {

    // هوية داكنة مستوحاة من أيقونة المشاركة المرفقة.
    private val cBg = 0xFF080B18.toInt()
    private val cCard = 0xFF12182A.toInt()
    private val cField = 0xFF1A2238.toInt()
    private val cText = 0xFFF4F5FF.toInt()
    private val cSub = 0xFFA6AEC8.toInt()
    private val cPrimary = 0xFF655BFF.toInt()
    private val cOk = 0xFF2CCB9A.toInt()
    private val cWarn = 0xFFFFB74D.toInt()
    private val cErr = 0xFFFF6D83.toInt()
    private val cBorder = 0xFF28314B.toInt()

    private lateinit var prefs: PrefsManager
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var etName: EditText
    private lateinit var etPass: EditText
    private lateinit var etPort: EditText
    private lateinit var etPath: EditText
    private lateinit var swUpload: Switch
    private lateinit var swDelete: Switch
    private lateinit var swScreen: Switch
    private lateinit var btnMain: ServerSwipeControl
    private lateinit var pill: TextView
    private lateinit var tvStatusMsg: TextView
    private lateinit var runCard: LinearLayout
    private lateinit var ivQr: ImageView
    private lateinit var btnQrMode: Button
    private lateinit var tvSsid: TextView
    private lateinit var tvPass: TextView
    private lateinit var tvUrl: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvSentRate: TextView
    private lateinit var tvReceivedRate: TextView
    private lateinit var tvSentTotal: TextView
    private lateinit var tvReceivedTotal: TextView
    private lateinit var tvMode: TextView
    private lateinit var settingsViews: List<View>
    private lateinit var homeScroll: ScrollView
    private lateinit var settingsScroll: ScrollView
    private lateinit var homeTabItem: TextView
    private lateinit var settingsTabItem: TextView
    private var lastSampleAt = 0L
    private var lastSentBytes = 0L
    private var lastReceivedBytes = 0L

    private var qrWifi = true
    private var lastQrKey: String? = null

    private val listener: () -> Unit = { refresh() }
    private val ticker = object : Runnable {
        override fun run() {
            refreshStats()
            ui.postDelayed(this, 1000)
        }
    }

    // ---------- أدوات بناء الواجهة ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        setStroke(dp(1), cBorder)
    }

    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(cCard, 0xFF151D32.toInt())
        ).apply {
            cornerRadii = floatArrayOf(
                dp(22).toFloat(), dp(22).toFloat(), dp(16).toFloat(), dp(16).toFloat(),
                dp(9).toFloat(), dp(9).toFloat(), dp(18).toFloat(), dp(18).toFloat()
            )
            setStroke(dp(1), cBorder)
        }
        setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = lp(bottom = 12)
    }

    private fun heading(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setTextColor(cText)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(8))
    }

    private fun small(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(cSub)
    }

    private fun buttonShape(color: Int, filled: Boolean): GradientDrawable {
        val base = if (filled) {
            val top = Color.rgb(
                minOf(255, (Color.red(color) * 1.15f).toInt()),
                minOf(255, (Color.green(color) * 1.15f).toInt()),
                minOf(255, (Color.blue(color) * 1.15f).toInt())
            )
            GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, color))
        } else {
            GradientDrawable().apply { setColor(0xFF19213A.toInt()) }
        }
        return base.apply {
            cornerRadii = floatArrayOf(
                dp(17).toFloat(), dp(17).toFloat(), dp(17).toFloat(), dp(17).toFloat(),
                dp(7).toFloat(), dp(7).toFloat(), dp(17).toFloat(), dp(17).toFloat()
            )
            setStroke(dp(1), if (filled) 0x72FFFFFF else color)
        }
    }

    private fun button(t: String, color: Int, filled: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 14f
        setTextColor(if (filled) 0xFFFFFFFF.toInt() else color)
        letterSpacing = 0.01f
        background = RippleDrawable(
            ColorStateList.valueOf(0x44FFFFFF),
            buttonShape(color, filled),
            buttonShape(0xFFFFFFFF.toInt(), true)
        )
        backgroundTintList = null
        setPadding(dp(14), dp(8), dp(14), dp(8))
        minHeight = dp(44)
        stateListAnimator = null
        elevation = dp(if (filled) 2 else 0).toFloat()
        setOnClickListener { onClick() }
    }

    private fun metric(title: String, value: TextView, total: TextView): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cField, 14)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(small(title))
            value.textSize = 19f
            value.setTextColor(cText)
            value.typeface = android.graphics.Typeface.DEFAULT_BOLD
            addView(value, lp(top = 4))
            total.textSize = 11f
            total.setTextColor(cSub)
            addView(total, lp(top = 2))
        }

    private fun selectTab(settings: Boolean) {
        homeScroll.visibility = if (settings) View.GONE else View.VISIBLE
        settingsScroll.visibility = if (settings) View.VISIBLE else View.GONE
        if (::homeTabItem.isInitialized) {
            homeTabItem.setTextColor(if (settings) cSub else cText)
            settingsTabItem.setTextColor(if (settings) cText else cSub)
            homeTabItem.background = if (settings) null else rounded(cField, 12)
            settingsTabItem.background = if (settings) rounded(cField, 12) else null
        }
    }

    private fun field(hint: String, value: String, number: Boolean = false) = EditText(this).apply {
        setText(value)
        this.hint = hint
        setSingleLine()
        textSize = 16f
        setTextColor(cText)
        setHintTextColor(cSub)
        background = rounded(cField, 10)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (number) inputType = InputType.TYPE_CLASS_NUMBER
    }

    private fun labeled(parent: LinearLayout, label: String, f: View) {
        parent.addView(small(label).apply { setPadding(0, dp(10), 0, dp(4)) })
        parent.addView(f, lp())
    }

    private fun switchRow(text: String, checked: Boolean) = Switch(this).apply {
        this.text = text
        isChecked = checked
        textSize = 14f
        setTextColor(cText)
        setPadding(0, dp(8), 0, dp(8))
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(states, intArrayOf(cOk, 0xFF8790AA.toInt()))
        trackTintList = ColorStateList(states, intArrayOf(0x773AD6A4, 0x55434D66))
    }

    /** صف معلومات: عنوان صغير + قيمة قابلة للتحديد + زر نسخ. */
    private fun infoRow(parent: LinearLayout, label: String, tv: TextView) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(small(label))
        tv.apply { textSize = 16f; setTextColor(cText); setTextIsSelectable(true) }
        col.addView(tv)
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button("نسخ", cPrimary, false) { copy(tv.text.toString()) })
        parent.addView(row, lp())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsManager(this)

        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        homeScroll = ScrollView(this).apply { setBackgroundColor(cBg); isFillViewport = true }
        homeScroll.addView(col)
        val settingsCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        settingsScroll = ScrollView(this).apply { setBackgroundColor(cBg); isFillViewport = true }
        settingsScroll.addView(settingsCol)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
        }
        val pages = FrameLayout(this)
        pages.addView(homeScroll, FrameLayout.LayoutParams(-1, -1))
        pages.addView(settingsScroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(pages, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = rounded(cCard, 18)
        }
        homeTabItem = TextView(this).apply {
            text = "⌂\nالرئيسية"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
            setOnClickListener { selectTab(false) }
        }
        settingsTabItem = TextView(this).apply {
            text = "⚙\nالإعدادات"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
            setOnClickListener { selectTab(true) }
        }
        nav.addView(homeTabItem, LinearLayout.LayoutParams(0, dp(54), 1f))
        nav.addView(settingsTabItem, LinearLayout.LayoutParams(0, dp(54), 1f))
        root.addView(nav, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(16), dp(4), dp(16), dp(10))
        })
        setContentView(root)
        selectTab(false)

        // رأس الصفحة + حالة
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(com.portablefileserver.R.drawable.brand_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(cField, 16)
            clipToOutline = true
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginEnd = dp(12) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(this).apply {
            text = "Portable File Server"; textSize = 18f; setTextColor(cText)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        titles.addView(small("مشاركة محلية سريعة وآمنة"))
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        pill = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(12), dp(5), dp(12), dp(5))
        }
        header.addView(pill)
        col.addView(header, lp(bottom = 12))

        // آخر انهيار (إن وجد)
        val crash = File(filesDir, "crash.log")
        if (crash.exists()) {
            val cc = card()
            cc.addView(heading("⚠ آخر انهيار مسجّل"))
            cc.addView(TextView(this).apply { text = crash.readText().take(1200); textSize = 11f; setTextColor(cErr) })
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(button("نسخ", cPrimary, false) { copy(crash.readText()) })
            r.addView(button("إخفاء", cSub, false) { crash.delete(); cc.visibility = View.GONE })
            cc.addView(r, lp(top = 8))
            col.addView(cc)
        }

        // زر التشغيل الرئيسي + رسالة الحالة
        val main = card()
        btnMain = ServerSwipeControl(this).apply { onAction = { toggle() } }
        main.addView(btnMain, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78)))
        tvStatusMsg = TextView(this).apply { textSize = 13f; setTextColor(cSub); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        main.addView(tvStatusMsg)
        col.addView(main)

        val metrics = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        tvSentRate = TextView(this).apply { text = "0 B/s" }
        tvSentTotal = TextView(this).apply { text = "إجمالي: 0 B" }
        tvReceivedRate = TextView(this).apply { text = "0 B/s" }
        tvReceivedTotal = TextView(this).apply { text = "إجمالي: 0 B" }
        metrics.addView(metric("تنزيل إلى الأجهزة", tvSentRate, tvSentTotal),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        metrics.addView(metric("رفع من الأجهزة", tvReceivedRate, tvReceivedTotal),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
        col.addView(metrics, lp(bottom = 12))

        // بطاقة الاتصال (تظهر عند التشغيل)
        runCard = card().apply { visibility = View.GONE }
        runCard.addView(heading("بيانات الاتصال"))
        ivQr = ImageView(this)
        runCard.addView(ivQr, LinearLayout.LayoutParams(dp(220), dp(220)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        btnQrMode = button("عرض QR الرابط", cPrimary, false) { qrWifi = !qrWifi; refresh() }
        runCard.addView(btnQrMode, lp(top = 6))
        tvSsid = TextView(this); tvPass = TextView(this); tvUrl = TextView(this)
        infoRow(runCard, "اسم الشبكة", tvSsid)
        infoRow(runCard, "كلمة المرور", tvPass)
        infoRow(runCard, "الرابط", tvUrl)
        tvMode = small("")
        runCard.addView(tvMode)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("فتح في المتصفح", cPrimary) { openUrl() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(button("مشاركة", cPrimary, false) { shareInfo() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        runCard.addView(actions, lp(top = 8))
        tvStats = TextView(this).apply { textSize = 13f; setTextColor(cSub); gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        runCard.addView(tvStats)
        runCard.addView(small("١. اتصل بالشبكة من الجهاز الآخر (امسح QR أو أدخل الاسم والكلمة)\n٢. افتح الرابط في المتصفح").apply { setPadding(0, dp(10), 0, 0) })
        col.addView(runCard)

        // الإعدادات
        settingsCol.addView(TextView(this).apply {
            text = "الإعدادات"
            textSize = 24f
            setTextColor(cText)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, lp(bottom = 4))
        settingsCol.addView(small("خصّص الشبكة ومجلدات النقل والصلاحيات."), lp(bottom = 16))
        val sc = card()
        sc.addView(heading("إعدادات الشبكة"))
        etName = field("مثال: Share", prefs.networkName)
        labeled(sc, "اسم الشبكة (يظهر DIRECT-PF- قبل الاسم، أحرف إنجليزية وأرقام)", etName)
        etPass = field("8 أحرف على الأقل", prefs.password)
        labeled(sc, "كلمة المرور", etPass)
        val passRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnRandom = button("كلمة عشوائية", cPrimary, false) { etPass.setText(randomPassword()) }
        passRow.addView(btnRandom)
        sc.addView(passRow, lp(top = 6))
        etPort = field("8080", prefs.port.toString(), true)
        labeled(sc, "المنفذ", etPort)
        etPath = field("مجلد المشاركة", prefs.rootPath)
        labeled(sc, "مجلد المشاركة", etPath)
        val pathRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnApp = button("مجلد التطبيق", cPrimary, false) { etPath.setText(prefs.defaultRoot()) }
        val btnDl = button("التنزيلات", cPrimary, false) { useDownloads() }
        pathRow.addView(btnApp)
        pathRow.addView(btnDl)
        sc.addView(pathRow, lp(top = 6))
        swUpload = switchRow("السماح للأجهزة بالرفع وإنشاء المجلدات", prefs.allowUpload)
        swDelete = switchRow("السماح بالحذف وإعادة التسمية", prefs.allowDelete)
        swScreen = switchRow("إبقاء الشاشة مضاءة أثناء التشغيل", prefs.keepScreenOn)
        sc.addView(swUpload, lp(top = 8))
        sc.addView(swDelete, lp())
        sc.addView(swScreen, lp())
        settingsCol.addView(sc)
        settingsViews = listOf(etName, etPass, etPort, etPath, btnRandom, btnApp, btnDl, swUpload, swDelete)

        // نصائح
        val tc = card()
        tc.addView(heading("لاستمرار التشغيل"))
        tc.addView(small("بعض الهواتف توقف التطبيق في الخلفية. استثنِ التطبيق من توفير البطارية حتى لا تنقطع الشبكة أثناء النقل."))
        tc.addView(button("استثناء من توفير البطارية", cPrimary, false) { ignoreBattery() }, lp(top = 8))
        settingsCol.addView(tc)
        val speedNote = card()
        speedNote.addView(heading("نقل أسرع للملفات الكبيرة"))
        speedNote.addView(small("يختار التطبيق نطاق Wi‑Fi ‏5 GHz تلقائياً عندما يدعمه الهاتف، ويرجع إلى 2.4 GHz إذا لم يتوفر. أبقِ الهاتف والأجهزة قريبة أثناء النقل."))
        settingsCol.addView(speedNote)
    }

    override fun onResume() {
        super.onResume()
        ServerRuntime.addListener(listener)
        refresh()
        ui.post(ticker)
    }

    override fun onPause() {
        ServerRuntime.removeListener(listener)
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    // ---------- تحديث الواجهة ----------
    private fun refresh() {
        val r = ServerRuntime
        val (pillText, pillColor) = when (r.state) {
            ServerRuntime.State.RUNNING -> "● يعمل" to cOk
            ServerRuntime.State.STARTING -> "● جارٍ التشغيل" to cWarn
            ServerRuntime.State.ERROR -> "● خطأ" to cErr
            ServerRuntime.State.STOPPED -> "● متوقف" to 0xFF80868B.toInt()
        }
        pill.text = pillText
        pill.background = rounded(pillColor, 20)
        tvStatusMsg.text = if (r.state == ServerRuntime.State.RUNNING) "" else r.status
        tvStatusMsg.setTextColor(if (r.state == ServerRuntime.State.ERROR) cErr else cSub)

        btnMain.updateState(r.state)
        settingsViews.forEach { it.isEnabled = !r.active }

        if (r.active && prefs.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val info = r.info
        val url = r.url
        if (r.active && info != null && url != null) {
            runCard.visibility = View.VISIBLE
            tvSsid.text = info.ssid
            tvPass.text = info.password
            tvUrl.text = url
            tvMode.text = "الوضع: " + info.mode
            val text = if (qrWifi) QrGenerator.wifi(info.ssid, info.password) else url
            btnQrMode.text = if (qrWifi) "عرض QR الرابط" else "عرض QR الشبكة"
            val key = (if (qrWifi) "w:" else "u:") + text
            if (key != lastQrKey) {
                lastQrKey = key
                ivQr.setImageBitmap(QrGenerator.make(text, 600))
            }
            refreshStats()
        } else {
            runCard.visibility = View.GONE
            lastQrKey = null
        }
    }

    private fun refreshStats() {
        val sent = ServerRuntime.bytesSent.get()
        val received = ServerRuntime.bytesReceived.get()
        if (!ServerRuntime.active || ServerRuntime.url == null) {
            lastSampleAt = 0L
            lastSentBytes = sent
            lastReceivedBytes = received
            tvSentRate.text = "0 B/s"
            tvReceivedRate.text = "0 B/s"
            tvSentTotal.text = "إجمالي: " + fmt(sent)
            tvReceivedTotal.text = "إجمالي: " + fmt(received)
            tvStats.text = "الخادم متوقف"
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        if (lastSampleAt == 0L) {
            lastSampleAt = now
            lastSentBytes = sent
            lastReceivedBytes = received
        } else {
            val elapsed = (now - lastSampleAt).coerceAtLeast(1L)
            val downRate = ((sent - lastSentBytes).coerceAtLeast(0L) * 1000L) / elapsed
            val upRate = ((received - lastReceivedBytes).coerceAtLeast(0L) * 1000L) / elapsed
            tvSentRate.text = fmt(downRate) + "/s"
            tvReceivedRate.text = fmt(upRate) + "/s"
            lastSampleAt = now
            lastSentBytes = sent
            lastReceivedBytes = received
        }
        tvSentTotal.text = "إجمالي: " + fmt(sent)
        tvReceivedTotal.text = "إجمالي: " + fmt(received)
        tvStats.text = "الأجهزة النشطة: " + ServerRuntime.activeClients() +
            "   •   الطلبات: " + ServerRuntime.requests.get()
    }

    private fun fmt(n: Long): String = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> String.format("%.1f KB", n / 1024.0)
        n < 1024L * 1024 * 1024 -> String.format("%.1f MB", n / 1048576.0)
        else -> String.format("%.2f GB", n / 1073741824.0)
    }

    // ---------- الإجراءات ----------
    private fun toggle() {
        if (ServerRuntime.active) {
            startService(Intent(this, ServerService::class.java).setAction(ServerService.ACTION_STOP))
            return
        }
        val name = etName.text.toString().trim()
        val pass = etPass.text.toString()
        val port = etPort.text.toString().toIntOrNull() ?: 0
        val path = etPath.text.toString().trim()
        when {
            name.isEmpty() -> { toast("أدخل اسم الشبكة"); return }
            pass.length < 8 -> { toast("كلمة المرور يجب أن تكون 8 أحرف على الأقل"); return }
            port !in 1024..65535 -> { toast("المنفذ يجب أن يكون بين 1024 و 65535"); return }
            path.isEmpty() -> { toast("حدد مجلد المشاركة"); return }
        }
        prefs.networkName = name
        prefs.password = pass
        prefs.port = port
        prefs.rootPath = path
        prefs.allowUpload = swUpload.isChecked
        prefs.allowDelete = swDelete.isChecked
        prefs.keepScreenOn = swScreen.isChecked

        val missing = neededPermissions()
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else startServer()
    }

    private fun neededPermissions(): List<String> {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            l.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        return l.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val wifiPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES else Manifest.permission.ACCESS_FINE_LOCATION
        if (checkSelfPermission(wifiPerm) == PackageManager.PERMISSION_GRANTED) startServer()
        else toast("الصلاحية مطلوبة لإنشاء الشبكة")
    }

    private fun startServer() {
        val path = File(prefs.rootPath)
        if (!path.exists()) path.mkdirs()
        if (!path.isDirectory) { toast("مجلد المشاركة غير صالح"); return }
        try {
            ContextCompat.startForegroundService(
                this, Intent(this, ServerService::class.java).setAction(ServerService.ACTION_START)
            )
        } catch (e: Exception) {
            toast("تعذّر تشغيل الخدمة: " + (e.message ?: ""))
        }
    }

    private fun useDownloads() {
        etPath.setText(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath)
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            toast("امنح صلاحية الوصول لكل الملفات ثم ارجع")
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }
    }

    private fun ignoreBattery() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } else {
                toast("التطبيق مستثنى بالفعل")
            }
        } catch (e: Exception) {
            toast("تعذّر فتح الإعداد")
        }
    }

    private fun randomPassword(): String {
        val alphabet = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val rnd = SecureRandom()
        return (1..10).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
    }

    private fun copy(text: String) {
        try {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("pfs", text))
            toast("تم النسخ")
        } catch (e: Exception) {
            toast("تعذّر النسخ")
        }
    }

    private fun openUrl() {
        val u = ServerRuntime.url ?: return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        } catch (e: Exception) {
            toast("لا يوجد متصفح")
        }
    }

    private fun shareInfo() {
        val info = ServerRuntime.info ?: return
        val url = ServerRuntime.url ?: return
        val text = "الشبكة: " + info.ssid + "\nكلمة المرور: " + info.password + "\nالرابط: " + url
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "مشاركة بيانات الاتصال"))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
