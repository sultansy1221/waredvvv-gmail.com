package com.portablefileserver.server

/**
 * صفحة الويب التي تظهر للأجهزة المتصلة.
 * ملاحظة: لا تستخدم رمز الدولار داخل النص لأن Kotlin يفسّره كمتغير.
 */
object WebUi {
    val HTML = """<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>مشاركة الملفات</title>
<style>
:root{--bg:#080b18;--card:#12182a;--card2:#171e33;--tx:#f4f5ff;--sub:#a6aec8;--pr:#786bff;--bd:#28314b;--er:#ff6d83;--ok:#2ccb9a;--hv:#1a2340}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:radial-gradient(ellipse at 85% -10%,#24205a 0,transparent 36%),var(--bg);color:var(--tx)}
header{background:rgba(8,11,24,.88);color:var(--tx);padding:14px max(18px,calc((100% - 1040px)/2));display:flex;align-items:center;justify-content:space-between;gap:14px;position:sticky;top:0;z-index:5;border-bottom:1px solid rgba(255,255,255,.07);backdrop-filter:blur(18px)}
.brand{display:flex;align-items:center;gap:12px;min-width:0}
.brand img{width:48px;height:48px;object-fit:cover;border-radius:15px;border:1px solid var(--bd);box-shadow:0 8px 28px #090b2066}
.brand b{font-size:17px;display:block}
.brand small{font-size:12px;color:var(--sub);display:block;margin-top:2px}
#free{font-size:12px;color:var(--sub);background:var(--card);border:1px solid var(--bd);padding:8px 12px;border-radius:999px;white-space:nowrap}
main{max-width:1040px;margin:0 auto;padding:22px 18px 50px}
.hero{position:relative;overflow:hidden;border:1px solid #4a448355;border-radius:28px 28px 10px 28px;padding:24px 26px;margin-bottom:18px;background:linear-gradient(120deg,#171a39 0%,#191b35 48%,#241749 100%);box-shadow:0 16px 50px #0003}
.hero:after{content:"";position:absolute;width:210px;height:210px;border-radius:50%;left:-50px;top:-100px;background:radial-gradient(circle,#705cff66,transparent 70%);pointer-events:none}
.eyebrow{font-size:11px;font-weight:700;letter-spacing:.08em;color:#b8b1ff}
.hero h1{font-size:clamp(22px,4vw,32px);line-height:1.25;margin:8px 0}
.hero p{color:#c0c4d7;margin:0;max-width:620px;line-height:1.7;font-size:14px}
.heroNote{margin-top:18px;color:#d2d5e6;font-size:12px;display:flex;align-items:center;gap:8px}
.heroNote i{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--ok);box-shadow:0 0 12px #2ccb9a}
.tool{display:flex;gap:9px;flex-wrap:wrap;align-items:center;margin-bottom:11px}
.tool input[type=search]{flex:1;min-width:140px}
input,select{background:var(--card);color:var(--tx);border:1px solid var(--bd);border-radius:12px;padding:11px 13px;font-size:14px;outline:none}
input:focus,select:focus{border-color:#786bff;box-shadow:0 0 0 3px #786bff26}
button,.btn{background:linear-gradient(115deg,transparent 28%,#ffffff26 50%,transparent 72%) 110% 0/230% 100%,linear-gradient(135deg,#7468ff,#5148dd);color:#fff;border:1px solid #ffffff35;border-radius:18px 18px 7px 18px;padding:10px 15px;font-size:14px;font-weight:650;cursor:pointer;display:inline-block;transition:transform .18s,filter .18s,background-position .5s;box-shadow:0 7px 22px #5248dd30}
button:hover,.btn:hover{filter:brightness(1.1);transform:translateY(-2px);background-position:0 0,0 0}
button:active,.btn:active{transform:scale(.97)}
button:focus-visible,.btn:focus-visible{outline:2px solid #a49dff;outline-offset:3px}
button.g,.btn.g{background:var(--card);color:var(--tx);border:1px solid var(--bd);box-shadow:none}
button.r{background:transparent;color:var(--er);border:1px solid var(--bd);box-shadow:none}
button.i{padding:8px 10px;background:transparent;color:var(--sub);border:1px solid transparent;font-size:15px;box-shadow:none}
button.i:hover{color:var(--tx);background:var(--hv);border-color:var(--bd)}
[hidden]{display:none!important}
#crumbs{font-size:13px;margin:8px 2px 12px;display:flex;gap:6px;flex-wrap:wrap}
#crumbs a{color:var(--pr);cursor:pointer;text-decoration:none}
#crumbs span{color:var(--sub)}
.list{background:var(--card);border-radius:22px 22px 9px 22px;overflow:hidden;border:1px solid var(--bd);box-shadow:0 14px 38px #0002}
.row{display:flex;align-items:center;gap:11px;padding:13px 15px;border-bottom:1px solid var(--bd);transition:background .14s}
.row:last-child{border-bottom:0}
.row:hover{background:var(--hv)}
.row .ic{font-size:20px;width:38px;height:38px;display:grid;place-items:center;border-radius:14px 14px 6px 14px;background:var(--card2);text-align:center}
.row .nm{flex:1;min-width:0;cursor:pointer}
.row .nm div:first-child{word-break:break-word}
.row .mt{font-size:11px;color:var(--sub);margin-top:3px}
.row input[type=checkbox]{width:18px;height:18px}
.empty{padding:48px 20px;text-align:center;color:var(--sub)}
#up{margin-bottom:12px}
#up .u{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:12px 14px;margin-bottom:8px;font-size:13px}
.bar{height:7px;background:var(--bd);border-radius:8px;margin-top:9px;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#5f5bff,#13cbe0);border-radius:8px;transition:width .15s}
.u.done .bar i{background:var(--ok)}.u.fail .bar i{background:var(--er)}
#drop{position:fixed;inset:14px;background:#161735ed;color:#fff;border:2px dashed #9b91ff;border-radius:26px;display:flex;align-items:center;justify-content:center;font-size:24px;z-index:20;backdrop-filter:blur(10px)}
#modal{position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:30;display:flex;flex-direction:column}
#modal .top{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;color:#fff;gap:8px}
#modal .top span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
#pv{flex:1;display:flex;align-items:center;justify-content:center;overflow:auto;padding:8px}
#pv img,#pv video,#pv iframe{max-width:100%;max-height:100%;border:0}
#pv iframe{width:100%;height:100%;background:#fff}
#pv pre{background:var(--card);color:var(--tx);padding:14px;border-radius:10px;max-width:100%;overflow:auto;white-space:pre-wrap;word-break:break-word;direction:ltr;text-align:left;margin:0}
#toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#323232;color:#fff;padding:10px 18px;border-radius:24px;font-size:14px;z-index:40;opacity:0;pointer-events:none;transition:opacity .2s}
#toast.show{opacity:1}
@media(max-width:600px){header{padding:11px 14px}.brand img{width:42px;height:42px}.brand b{font-size:15px}.brand small{font-size:11px}#free{white-space:normal;font-size:10px;padding:6px 8px}main{padding:16px 12px 34px}.hero{padding:20px;border-radius:20px}.row{gap:8px;padding:11px 10px}.row .ic{width:34px;height:34px}.tool button,.tool .btn{padding:10px 11px}}
</style></head><body>
<header><div class="brand"><img src="/brand.png" alt="شعار مشاركة الملفات"><div><b>مشاركة الملفات</b><small>خادم محلي • نقل مباشر بين أجهزتك</small></div></div><span id="free"></span></header>
<main>
<section class="hero"><span class="eyebrow">PRIVATE • LOCAL • FAST</span><h1>كل ملفاتك في مكان واحد</h1><p>تصفّح المجلدات وارفع الملفات أو نزّلها مباشرة عبر الشبكة المحلية، من دون وسيط سحابي.</p><div class="heroNote"><i></i> اتصال محلي مباشر بين الأجهزة</div></section>
<div class="tool">
  <input type="search" id="q" placeholder="بحث في هذا المجلد…">
  <select id="sort"><option value="name">الاسم</option><option value="size">الحجم</option><option value="date">الأحدث</option></select>
</div>
<div class="tool">
  <label class="btn" id="bUp">⬆ رفع ملفات<input type="file" id="fi" multiple hidden></label>
  <button class="g" id="bMk">＋ مجلد</button>
  <button class="g" id="bAll">تحديد الكل</button>
  <button id="bZip" hidden>⬇ تحميل المحدد (zip)</button>
  <button class="r" id="bDel" hidden>🗑 حذف المحدد</button>
</div>
<div id="crumbs"></div>
<div id="up"></div>
<div class="list" id="list"></div>
</main>
<div id="drop" hidden>أفلت الملفات هنا للرفع</div>
<div id="modal" hidden>
  <div class="top"><span id="pvn"></span><a class="btn" id="pvd" href="#">تحميل</a><button class="g" id="pvc" style="color:#fff">✕ إغلاق</button></div>
  <div id="pv"></div>
</div>
<div id="toast"></div>
<script>
(function(){
var cur="",items=[],sel={},info={upload:true,delete:true,free:0,total:0};
function g(id){return document.getElementById(id);}
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined)e.textContent=x;return e;}
function enc(p){return p.split("/").map(encodeURIComponent).join("/");}
function join(a,b){return a?a+"/"+b:b;}
function sz(n){if(n<1024)return n+" B";if(n<1048576)return (n/1024).toFixed(1)+" KB";if(n<1073741824)return (n/1048576).toFixed(1)+" MB";return (n/1073741824).toFixed(2)+" GB";}
function ext(n){var i=n.lastIndexOf(".");return i<0?"":n.slice(i+1).toLowerCase();}
var T={img:["jpg","jpeg","png","gif","webp","bmp","svg"],vid:["mp4","webm","mkv","mov","3gp","m4v"],aud:["mp3","wav","ogg","m4a","aac","flac"],txt:["txt","md","log","json","xml","csv","html","js","css","kt","java","py","ini","yml","yaml"],pdf:["pdf"]};
function kind(n){var e=ext(n);for(var k in T){if(T[k].indexOf(e)>=0)return k;}return "";}
function icon(it){if(it.dir)return "📂";var k=kind(it.name);return {img:"🖼",vid:"🎬",aud:"🎵",txt:"📝",pdf:"📕"}[k]||(["zip","rar","7z","gz","tar"].indexOf(ext(it.name))>=0?"🗜":(ext(it.name)=="apk"?"🤖":"📄"));}
function toast(m){var t=g("toast");t.textContent=m;t.className="show";clearTimeout(toast.h);toast.h=setTimeout(function(){t.className="";},2600);}
function api(url,data){
  return fetch(url,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams(data).toString()})
   .then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||("خطأ "+r.status));return j;});});
}
function selKeys(){return Object.keys(sel).filter(function(k){return sel[k];});}
function load(p){
  cur=p;sel={};
  fetch("/api/list?path="+encodeURIComponent(p)).then(function(r){return r.json();})
   .then(function(d){items=d.items||[];render();})
   .catch(function(){toast("تعذّر تحميل القائمة، تحقق من الاتصال بالشبكة");});
}
function loadInfo(){
  fetch("/api/info").then(function(r){return r.json();}).then(function(d){
    info=d;
    g("bUp").hidden=!d.upload;g("bMk").hidden=!d.upload;
    g("free").textContent="المساحة الحرة: "+sz(d.free)+" من "+sz(d.total);
    render();
  });
}
function crumbs(){
  var c=g("crumbs");c.innerHTML="";
  var a=el("a",null,"الرئيسية");a.onclick=function(){load("");};c.appendChild(a);
  var acc="";
  cur.split("/").filter(function(x){return x;}).forEach(function(x){
    acc=join(acc,x);var path=acc;
    c.appendChild(el("span",null,"/"));
    var l=el("a",null,x);l.onclick=function(){load(path);};c.appendChild(l);
  });
}
function view(){
  var q=g("q").value.trim().toLowerCase(),s=g("sort").value;
  var l=items.filter(function(i){return !q||i.name.toLowerCase().indexOf(q)>=0;});
  l.sort(function(a,b){
    if(a.dir!==b.dir)return a.dir?-1:1;
    if(s==="size")return b.size-a.size;
    if(s==="date")return b.mtime-a.mtime;
    return a.name.toLowerCase()<b.name.toLowerCase()?-1:1;
  });
  return l;
}
function render(){
  crumbs();
  var box=g("list");box.innerHTML="";
  var l=view();
  if(!l.length){box.appendChild(el("div","empty",items.length?"لا نتائج":"المجلد فارغ"));}
  l.forEach(function(it){
    var full=join(cur,it.name);
    var row=el("div","row");
    var cb=el("input");cb.type="checkbox";cb.checked=!!sel[full];
    cb.onchange=function(){sel[full]=cb.checked;bulk();};
    row.appendChild(cb);
    row.appendChild(el("div","ic",icon(it)));
    var nm=el("div","nm");
    nm.appendChild(el("div",null,it.name));
    nm.appendChild(el("div","mt",(it.dir?"مجلد":sz(it.size))+" • "+new Date(it.mtime).toLocaleString()));
    nm.onclick=function(){it.dir?load(full):open(full,it);};
    row.appendChild(nm);
    var dl=el("button","i",it.dir?"⬇ zip":"⬇");dl.title="تحميل";
    dl.onclick=function(){it.dir?zip([full]):download(full);};
    row.appendChild(dl);
    if(info["delete"]){
      var rn=el("button","i","✏");rn.title="إعادة تسمية";rn.onclick=function(){rename(full,it.name);};
      var rm=el("button","i","🗑");rm.title="حذف";rm.onclick=function(){remove([full]);};
      row.appendChild(rn);row.appendChild(rm);
    }
    box.appendChild(row);
  });
  bulk();
}
function bulk(){
  var n=selKeys().length;
  g("bZip").hidden=!n;g("bZip").textContent="⬇ تحميل المحدد ("+n+") zip";
  g("bDel").hidden=!n||!info["delete"];
  g("bAll").textContent=n?"إلغاء التحديد":"تحديد الكل";
}
function download(p){var a=el("a");a.href="/f/"+enc(p)+"?dl=1";a.download="";document.body.appendChild(a);a.click();a.remove();}
function zip(paths){
  var u="/api/zip?"+paths.map(function(p){return "p="+encodeURIComponent(p);}).join("&");
  var a=el("a");a.href=u;a.download="";document.body.appendChild(a);a.click();a.remove();
}
function remove(paths){
  if(!confirm("حذف "+paths.length+" عنصر؟ لا يمكن التراجع."))return;
  var i=0;
  (function next(){
    if(i>=paths.length){toast("تم الحذف");loadInfo();load(cur);return;}
    api("/api/delete",{path:paths[i++]}).then(next).catch(function(e){toast(e.message);load(cur);});
  })();
}
function rename(p,old){
  var n=prompt("الاسم الجديد",old);
  if(!n||n===old)return;
  api("/api/rename",{path:p,name:n}).then(function(){load(cur);}).catch(function(e){toast(e.message);});
}
function open(p,it){
  var k=kind(it.name),pv=g("pv");pv.innerHTML="";
  g("pvn").textContent=it.name;g("pvd").href="/f/"+enc(p)+"?dl=1";
  var url="/f/"+enc(p);
  if(k==="img"){var im=el("img");im.src=url;pv.appendChild(im);}
  else if(k==="vid"){var v=el("video");v.src=url;v.controls=true;v.autoplay=true;pv.appendChild(v);}
  else if(k==="aud"){var a=el("audio");a.src=url;a.controls=true;a.autoplay=true;pv.appendChild(a);}
  else if(k==="pdf"){var f=el("iframe");f.src=url;pv.appendChild(f);}
  else if(k==="txt"&&it.size<1048576){
    var pre=el("pre",null,"جارٍ التحميل…");pv.appendChild(pre);
    fetch(url).then(function(r){return r.text();}).then(function(t){pre.textContent=t;});
  }else{download(p);return;}
  g("modal").hidden=false;
}
function closePv(){g("modal").hidden=true;g("pv").innerHTML="";}
var queue=[],busy=false;
function enqueue(files){
  if(!info.upload){toast("الرفع معطّل من إعدادات التطبيق");return;}
  for(var i=0;i<files.length;i++)queue.push({f:files[i],dir:cur});
  if(!busy)next();
}
function next(){
  var job=queue.shift();
  if(!job){busy=false;loadInfo();load(cur);return;}
  busy=true;
  var box=el("div","u");var t=el("div",null,job.f.name+" ("+sz(job.f.size)+")");
  var bar=el("div","bar");var fill=el("i");bar.appendChild(fill);
  var st=el("div","mt","");box.appendChild(t);box.appendChild(bar);box.appendChild(st);g("up").appendChild(box);
  var x=new XMLHttpRequest(),t0=Date.now();
   x.open("POST","/api/upload?path="+encodeURIComponent(job.dir)+"&name="+encodeURIComponent(job.f.name));
   x.setRequestHeader("Content-Type","application/octet-stream");
  x.upload.onprogress=function(e){
    if(!e.lengthComputable)return;
    var p=Math.round(e.loaded*100/e.total);fill.style.width=p+"%";
    var s=(Date.now()-t0)/1000;st.textContent=p+"% • "+sz(e.loaded/Math.max(s,0.1))+"/ث";
  };
  x.onload=function(){
    if(x.status===200){box.className="u done";fill.style.width="100%";st.textContent="تم الرفع ✓";}
    else{box.className="u fail";var m="فشل";try{m=JSON.parse(x.responseText).error||m;}catch(e){}st.textContent=m;}
    setTimeout(function(){box.remove();},4000);next();
  };
  x.onerror=function(){box.className="u fail";st.textContent="انقطع الاتصال";setTimeout(function(){box.remove();},5000);next();};
   // إرسال الملف الخام يتجنب multipart المؤقت ونسخ الملف الكبير مرتين على الهاتف.
   x.send(job.f);
}
g("fi").onchange=function(e){enqueue(e.target.files);e.target.value="";};
g("bMk").onclick=function(){var n=prompt("اسم المجلد الجديد");if(n)api("/api/mkdir",{path:cur,name:n}).then(function(){load(cur);}).catch(function(e){toast(e.message);});};
g("bAll").onclick=function(){var any=selKeys().length>0;sel={};if(!any)view().forEach(function(i){sel[join(cur,i.name)]=true;});render();};
g("bZip").onclick=function(){zip(selKeys());};
g("bDel").onclick=function(){remove(selKeys());};
g("q").oninput=render;g("sort").onchange=render;
g("pvc").onclick=closePv;
document.addEventListener("keydown",function(e){if(e.key==="Escape")closePv();});
var depth=0;
window.addEventListener("dragenter",function(e){e.preventDefault();depth++;if(info.upload)g("drop").hidden=false;});
window.addEventListener("dragleave",function(e){e.preventDefault();depth=Math.max(0,depth-1);if(!depth)g("drop").hidden=true;});
window.addEventListener("dragover",function(e){e.preventDefault();});
window.addEventListener("drop",function(e){e.preventDefault();depth=0;g("drop").hidden=true;if(e.dataTransfer&&e.dataTransfer.files.length)enqueue(e.dataTransfer.files);});
loadInfo();load("");
})();
</script></body></html>"""
}
